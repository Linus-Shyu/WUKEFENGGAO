<?php include dirname(__FILE__) . "/../functions.php"; ?>

<?php
$meta_title = '通知';
?>

<?php include dirname(__FILE__) . "/../public/header.php"; ?>

<div class="mdui-container">

</div>

<?php include dirname(__FILE__) . "/../public/footer.php"; ?>
