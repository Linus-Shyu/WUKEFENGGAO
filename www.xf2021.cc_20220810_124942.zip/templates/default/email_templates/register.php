你正在注册 <?= $option['site_name'] ?> 账号，验证码为 <?= $code ?>
