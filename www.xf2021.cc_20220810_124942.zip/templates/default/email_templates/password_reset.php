你正在重置 <?= $option['site_name'] ?> 的密码，验证码为 <?= $code ?>
