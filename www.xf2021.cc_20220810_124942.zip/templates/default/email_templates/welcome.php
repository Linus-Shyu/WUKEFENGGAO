欢迎 <?= $user['username'] ?>，你已成功注册 <?= $option['site_name'] ?> 账号
