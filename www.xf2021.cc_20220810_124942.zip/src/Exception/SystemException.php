<?php

declare(strict_types=1);

namespace MDClub\Exception;

use Exception;

/**
 * 系统异常
 */
class SystemException extends Exception
{

}
