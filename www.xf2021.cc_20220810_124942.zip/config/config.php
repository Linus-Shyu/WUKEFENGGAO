<?php

return [
    'APP_DEBUG' => false,
    'DB_HOST' => '127.0.0.1',
    'DB_DATABASE' => 'www_xf2021_cc',
    'DB_USERNAME' => 'www_xf2021_cc',
    'DB_PASSWORD' => '3N6xHt47xS',
    'DB_PREFIX' => 'mc_'
];